Documentation/User Manual available online at: https://theme-sphere.com/docs/smartmag/
