<?php
/**
 * Mega Menu Links - Display recent posts from a parent category.
 */
?>
<ul class="mega-menu links mega-menu-links">
	<?php echo $sub_menu;  // phpcs:ignore WordPress.Security.EscapeOutput -- Safe markup generated via WordPress default Walker_Nav_Menu ?>
</ul>