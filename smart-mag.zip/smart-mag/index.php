<?php
/**
 * A fallback page in the template hierarchy when nothing else applies
 * 
 * Handle via archive.php
 */

// use default archive page
get_template_part('archive');

