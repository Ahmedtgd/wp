<?php
/**
 * Number control just extending the default text control.
 */
class Bunyad_Customizer_Controls_Number extends Bunyad_Customizer_Controls_Text {
	
	/**
	 * @var boolean Type of control
	 */
	public $type = 'bunyad-number';
}